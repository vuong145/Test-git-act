# Gói bàn giao: code đã rút gọn đến hết Chương 3 (31/10/2026)

Người gửi: Vương. Người nhận: Phong và agent tích hợp. Gói chỉ chứa code, config và
tài liệu, không chứa dữ liệu. Dữ liệu và đầu ra trên máy nhận giữ nguyên.

## 1. Nội dung gói

```
README_TICH_HOP.md            file này
MANIFEST_SHA256.txt           SHA-256 của mọi file trong gói
HASH_DOI_CHIEU_DAU_RA.txt     SHA-256 đầu ra hiện có trên máy Vương (để so sau khi chạy)
QMD_3_CAU_DA_SUA.md           3 câu trong QMD Vương đã sửa cho khớp code mới
chay_m2.bat                   chạy M2 + unittest trên Windows (đặt ở Chung/tools/)
2521001118_Nhom01_TieuLuan/
  requirements.txt            một file duy nhất, khóa phiên bản (.venv-m2)
  configs/                    4 file, không đổi nội dung so với trước
  scripts/                    toàn bộ code (xem mục 2)
  tests/                      6 file test + fixtures
```

## 2. Cấu trúc code mới

| File | Dòng | Vai trò | Mục bài |
|---|---:|---|---|
| `scripts/cleaning/common.py` | 459 | Phần chung làm sạch: quy tắc theo cột, `Audit`, `RowSequence`, `clean_dimension`, `clean_detail`, `verify_outputs`, `check_expected`, khung `run` | 3.1, 3.3 |
| `scripts/cleaning/clean_vuong.py` | 19 | Vương: aisles, departments, order_products__prior | 3.3 |
| `scripts/cleaning/clean_phong.py` | 102 | Phong: products, orders (tái dựng `order_number`, khôi phục `eval_set`), order_products__train | 3.3 |
| `scripts/cleaning/config_vuong.json`, `config_phong.json` | | Quy tắc, ký hiệu thiếu, số kỳ vọng; đường dẫn tương đối `../../` | |
| `scripts/summarize_cleaning.py` | 89 | Gộp báo cáo 2 người, đối chiếu SHA-256, nối thử train | 3.3 |
| `scripts/m1_build_master.py` | 251 | Master: 4 phép ghép trong vòng lặp, 13 tiêu chí, tệp tạm rồi xuất bản | 3.2 |
| `scripts/m1_quality_summary.py` | 62 | missingness_summary.csv, basket_quality_summary.json | 3.2 |
| `scripts/m1_benchmark.py`, `m1_common.py` | 788, 87 | **Giữ nguyên, không sửa** (đã chốt) | 3.2 |
| `scripts/project_io.py` | 112 | Tiện ích M2: đường dẫn, ghi tệp nguyên tử, `write_hashes`/`check_hashes`, thiết lập hình | |
| `scripts/m2_foundation.py` | 139 | G0: chia tập PCG64 seed 42, reference, bảng giỏ, lookup, `common/hashes.json` | 3.4 |
| `scripts/m2_profile_inputs.py` | 41 | shape/info/isna/describe | 3.2 |
| `scripts/m2_eda_summary.py`, `m2_plot_univariate.py` | 142, 72 | Phần Vương 3.4 | 3.4 |
| `scripts/m2_eda_multivariate.py`, `m2_plot_multivariate.py` | 136, 98 | Phần Phong 3.5; ghi `ban2/hashes.json` | 3.5 |
| `scripts/m2_hypothesis_tests.py` | 79 | Phần Phong 3.6; Holm tự viết giữ nguyên | 3.6 |
| `scripts/render_pdf.py` | 80 | Xuất PDF | |
| `scripts/README.md` | | Thứ tự chạy và các cổng kiểm tra | |

Tổng: 2.756 dòng code + 435 dòng test (trước đây khoảng 6.300 dòng, chưa kể 1.051 dòng `scripts/audit`).

## 3. Thứ tự chạy (từ thư mục bài)

```powershell
.\.venv-m2\Scripts\python.exe scripts/cleaning/clean_vuong.py     # 1 và 2 chạy song song được
.\.venv-m2\Scripts\python.exe scripts/cleaning/clean_phong.py
.\.venv-m2\Scripts\python.exe scripts/summarize_cleaning.py
.\.venv-m2\Scripts\python.exe scripts/m1_build_master.py           # KHÔNG chạy lại, xem mục 6
.\.venv-m2\Scripts\python.exe scripts/m1_quality_summary.py
.\.venv-m2\Scripts\python.exe scripts/m2_foundation.py
.\.venv-m2\Scripts\python.exe scripts/m2_profile_inputs.py
.\.venv-m2\Scripts\python.exe scripts/m2_eda_summary.py
.\.venv-m2\Scripts\python.exe scripts/m2_plot_univariate.py
.\.venv-m2\Scripts\python.exe scripts/m2_eda_multivariate.py
.\.venv-m2\Scripts\python.exe scripts/m2_plot_multivariate.py
.\.venv-m2\Scripts\python.exe scripts/m2_hypothesis_tests.py
.\.venv-m2\Scripts\python.exe -m unittest discover -s tests -p "test_*.py"
.\.venv-m2\Scripts\python.exe scripts/render_pdf.py --no-open
```

Tên và vị trí mọi file đầu ra mà QMD trích **không đổi**.

## 4. Các bước tích hợp trên máy nhận

1. **Sao lưu:** chuyển thư mục `scripts/`, `tests/`, `configs/` và các file `requirements*.txt` hiện có
   trong thư mục bài sang `TLCK/Chung/archive/code_cu_truoc_rut_gon_20261031/` (giữ cấu trúc).
2. **Chép vào:** chép `2521001118_Nhom01_TieuLuan/` trong gói đè lên thư mục bài (chỉ gồm
   `requirements.txt`, `configs/`, `scripts/`, `tests/`). Chép `chay_m2.bat` vào `TLCK/Chung/tools/`.
3. **Chuyển ra archive những file không còn dùng** (nếu còn trên máy nhận):
   - `BAO CAO/Bao cao EDA/common/`: mọi thứ trừ `hashes.json` (runs/, history/, *latest*.json,
     foundation_*.json, data_contract.json, split_manifest.json, environment_validation.json, *.log).
   - `BAO CAO/Bao cao EDA/ban1/` (các manifest JSON của lớp nghiệm thu cũ).
   - `BAO CAO/Bao cao EDA/ban2/`: `hypotheses_validation.json`, `plots_validation.json`,
     `insights_i4_i5.csv`, `plot_hashes.json`, `hypotheses_hashes.json`.
   - `BAO CAO/Bao cao lam sach/BAO_CAO_LAM_SACH.md`.
   - `DATA/Data đã làm sạch/Bảng master TLCK/master_train.parquet` (bản trùng; bản dùng là
     `DATA/Data đã làm sạch/master_train.parquet`).
   - `DATA/Data đã làm sạch/master_verification.json` (bản trùng; bản dùng nằm trong `Bảng master TLCK/`).
   - `drafts/`, `src/`, `images/`, `assets/hinh-minh-hoa.png`, file `.tex`.
   - `requirements.txt` ở gốc TLCK.
4. **Xóa cache:** mọi `__pycache__/`, `.mplcache/`.
5. **Sửa QMD:** áp 3 thay đổi trong `QMD_3_CAU_DA_SUA.md` nếu QMD trên máy nhận chưa có.
   Còn một câu cần người viết sửa lời: đoạn ngay dưới "Quy trình 5 bước xuất bản" có cụm
   "hai bản xuất bản giống nhau" — nay chỉ còn một bản Master.
6. **Nhật ký:** đường dẫn `scripts/audit/` trong `nhật ký làm việc.md` (dòng ~330) đổi thành
   `Chung/archive/code_cu_truoc_rut_gon_20261031/scripts/audit/`.
7. **Chạy kiểm chứng** theo mục 5.

## 5. Kiểm chứng sau khi tích hợp

- `chay_m2.bat` (hoặc các lệnh M2 ở mục 3) chạy hết, unittest đạt (29 test).
- So SHA-256 các file đầu ra với `HASH_DOI_CHIEU_DAU_RA.txt`. Lưu ý:
  - CSV làm sạch ghi bằng ký tự xuống dòng của hệ điều hành; hash trong file là của Windows.
  - Các bảng M2 ghi xuống dòng `\n` nên giống nhau trên mọi máy.
- Nếu chạy lại làm sạch: mở `BAO CAO/Bao cao lam sach/comparison_previous.csv`, cột
  `byte_identical_to_previous` phải là `True` cho cả 6 bảng.

Kết quả kiểm chứng phía Vương (chạy toàn bộ chuỗi trên cloud từ 6 file nhiễu): 57/59 đầu ra
khớp hash máy Vương; 6 CSV sạch khớp hash gốc; Master do code mới và code cũ tạo giống từng
byte trong cùng môi trường; mọi mục `checks` của `master_verification.json` và
`verification.json` trùng bản cũ.

## 6. Hai file khác hash là bình thường

- `comparison_previous.csv`: nhật ký so sánh với bản trước, tự đổi mỗi lần chạy.
- `master_train.parquet`: bản đang dùng tạo ngày 20/10 bằng pandas 3.0.3/PyArrow 24; môi trường
  `.venv-m2` là pandas 3.0.1/PyArrow 26 nên byte khác dù nội dung giống. **Không chạy lại M1**:
  bài trích kích thước 16.992.331 byte và SHA-256 của lượt 20/10, benchmark cũng đo trên lượt đó.
  Tiêu chí tái lập của Parquet là so nội dung (`pd.testing.assert_frame_equal`).

## 7. Những gì đã đổi về hành vi (không đổi kết quả)

- `run_report.json` của làm sạch không còn số RSS lấy mẫu (bài không trích; RSS lấy từ benchmark),
  không còn `code_sha256`; config nằm trong `run_report.json` thay cho `config_used.json`.
- Không còn tạo `SUMMARY.md` mỗi lượt làm sạch và `BAO_CAO_LAM_SACH.md`.
- G0 bỏ chuỗi manifest/acceptance/latest; cổng duy nhất là `BAO CAO/Bao cao EDA/common/hashes.json`
  (có thêm dtype thực đọc của reference). Định dạng `{"files": {...}, "counts": ..., "canonical_split_sha256": ...}`
  tương thích với file hiện có.
- `m2_profile_inputs.py` ghi vào `BAO CAO/Bao cao EDA/common/profile/`.
- Script M2 không còn sinh bản thảo QMD (`drafts/`) và `insights_i4_i5.csv`; lời văn nằm trong QMD.
- Hình ban2 lưu PDF với `pdf.fonttype 42` như hình ban1 (hình nhìn giống hệt).

## 8. Quyết định đã chốt, agent không được đổi

- Không sửa `m1_benchmark.py`, `m1_common.py`, `configs/hypotheses_config.json`.
- Không đổi tên/vị trí file đầu ra mà QMD trích.
- Không sửa lời văn của người viết trong QMD; chỉ sửa tên file/đường dẫn khi code đổi.
- Không ghi đè file trên máy khi chưa kiểm tra trạng thái hiện có; sao lưu trước khi thay.
