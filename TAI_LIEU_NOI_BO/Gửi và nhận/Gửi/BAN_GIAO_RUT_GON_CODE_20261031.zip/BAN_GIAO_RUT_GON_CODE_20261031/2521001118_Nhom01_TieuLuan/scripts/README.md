# Mã nguồn PRJ-08 (đến hết Chương 3)

Mọi lệnh chạy từ thư mục bài (thư mục chứa file QMD). Đường dẫn trong code và
config đều tương đối theo thư mục bài, không phụ thuộc thư mục đang đứng.

```powershell
uv venv --python 3.12 .venv-m2
uv pip install --python .venv-m2/Scripts/python.exe -r requirements.txt
```

## Thứ tự chạy

| Bước | Lệnh (`.venv-m2\Scripts\python.exe ...`) | Đầu ra chính | Mục |
|---|---|---|---|
| 1 | `scripts/cleaning/clean_vuong.py` | aisles, departments, order_products__prior | 3.1, 3.3 |
| 2 | `scripts/cleaning/clean_phong.py` | products, orders, order_products__train | 3.1, 3.3 |
| 3 | `scripts/summarize_cleaning.py` | `BAO CAO/Bao cao lam sach/verification.json`, before_after, relational_summary, comparison_previous | 3.3 |
| 4 | `scripts/m1_build_master.py` | `DATA/Data đã làm sạch/master_train.parquet`; join_audit, schema, dictionary, master_verification.json trong `Bảng master TLCK/` | 3.2 |
| 5 | `scripts/m1_quality_summary.py` | missingness_summary.csv, basket_quality_summary.json | 3.2 |
| 6 | `scripts/m1_benchmark.py` | master_benchmark.*, data_benchmark.* (giữ nguyên, không cần chạy lại) | 3.2 |
| 7 | `scripts/m2_foundation.py` | `DATA/Data phai sinh/M2/` (split, reference, giỏ, lookup) + `BAO CAO/Bao cao EDA/common/hashes.json` | 3.4 |
| 8 | `scripts/m2_profile_inputs.py` | `BAO CAO/Bao cao EDA/common/profile/` | 3.2 |
| 9 | `scripts/m2_eda_summary.py`, `scripts/m2_plot_univariate.py` | 8 CSV + reference_outliers.json; hình ban1 | 3.4 |
| 10 | `scripts/m2_eda_multivariate.py`, `scripts/m2_plot_multivariate.py` | `BAO CAO/Bao cao EDA/ban2/`; hình ban2 | 3.5 |
| 11 | `scripts/m2_hypothesis_tests.py` | hypotheses.csv, hypotheses_details.json | 3.6 |
| 12 | `scripts/render_pdf.py --no-open` | PDF của bài | — |

Bước 1 và 2 độc lập (chạy song song được); mỗi bước đọc thêm cột khóa từ file nhiễu
của bảng người kia để kiểm tra khóa ngoại. Bước 1 đọc lại 32 triệu dòng prior.

## Cổng kiểm tra

- Làm sạch: hash nguồn nhiễu khớp config; đọc lại CSV cuối; số dòng/giỏ/lượt sửa khớp
  config (`check_expected`); chỉ xuất bản khi đạt.
- M1: 4 phép ghép `validate="many_to_one"`, `indicator=True`; 13 tiêu chí trên tệp tạm.
- M2: `m2_foundation.py` kiểm tra Master và CSV sạch khớp hồ sơ M1/làm sạch rồi ghi
  `hashes.json`; mọi script sau gọi `project_io.check_hashes()` và dừng nếu hash lệch.
  Nhánh Phong dùng thêm `BAO CAO/Bao cao EDA/ban2/hashes.json`.

## Kiểm thử

```powershell
.\.venv-m2\Scripts\python.exe -m unittest discover -s tests -p "test_*.py"
```
