# 3 câu đã sửa trong QMD (máy Vương, 31/10/2026)

Chỉ sửa cho khớp tên file sau khi rút gọn code. Không sửa lời văn khác.

## 1. Mục 2.5 (môi trường)

Cũ:
> Các requirements chỉ đặt ngưỡng phiên bản tối thiểu của cleaning không phải bản khóa môi trường.

Mới:
> Phiên bản thư viện hiện hành được khóa trong `requirements.txt` của thư mục bài.

## 2. Mục 3.2 (sau bảng master_schema)

Cũ:
> G0 dùng chế độ đọc mặc định và lưu dtype thực đọc trong data contract.

Mới:
> G0 dùng chế độ đọc mặc định và lưu dtype thực đọc trong `hashes.json`.

## 3. Mục 3.2, bước 5 "Xuất bản từng tệp"

Cũ:
> Hai vị trí là `DATA/Data đã làm sạch/master_train.parquet` và bản sao tại `DATA/Data đã làm sạch/Bảng master TLCK/master_train.parquet`, tính từ thư mục bài. Thay thế nguyên tử áp dụng cho từng tệp, không phải giao dịch đồng thời cho hai bản và các báo cáo JSON/CSV. Nếu xuất bản bản thứ hai thất bại, bản thứ nhất có thể đã được cập nhật; cần chạy lại và đối chiếu hash trước sử dụng.

Mới:
> Đích xuất bản là `DATA/Data đã làm sạch/master_train.parquet`, tính từ thư mục bài. Thay thế nguyên tử áp dụng cho tệp Parquet, không phải giao dịch đồng thời cho Parquet và các báo cáo JSON/CSV; cần đối chiếu hash trước sử dụng.

## Còn lại (người viết sửa)

Đoạn ngay sau 5 bước xuất bản có câu "...13 tiêu chí đều đạt, hai bản xuất bản giống nhau..." —
nay chỉ còn một bản Master, cần sửa lời cho khớp.
