@echo off
rem Chay lai toan luong M2 (sau rut gon code 31/10) (cong cu tam, khong thuoc bai).
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0..\..\2521001118_Nhom01_TieuLuan"
set PY=.venv-m2\Scripts\python.exe
set LOG=%~dp0chay_m2_log.txt
echo BAT DAU %date% %time% > "%LOG%"
for %%s in (m2_foundation m2_profile_inputs m2_eda_summary m2_plot_univariate m2_eda_multivariate m2_plot_multivariate m2_hypothesis_tests) do (
  echo === %%s >> "%LOG%"
  %PY% scripts\%%s.py >> "%LOG%" 2>&1 || (echo LOI %%s >> "%LOG%" & goto :end)
)
echo === unittest >> "%LOG%"
%PY% -m unittest discover -s tests -p "test_*.py" >> "%LOG%" 2>&1
echo XONG >> "%LOG%"
:end
echo KET THUC %date% %time% >> "%LOG%"
